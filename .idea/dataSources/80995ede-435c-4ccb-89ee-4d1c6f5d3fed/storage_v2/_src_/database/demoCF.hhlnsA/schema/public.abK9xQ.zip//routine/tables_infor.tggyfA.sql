create function tables_infor(table_id character varying)
    returns TABLE(ten_mon character varying, so_luong integer, don_gia integer, thanh_tien integer)
    language plpgsql
as
$$
BEGIN
    select b1.ten_mon, amount, price,pay from receipt b2 inner join (select ten_mon,price,receipt_id,amount,pay from menu inner join receipt_infor
    on receipt_infor.ma_mon=menu.ma_mon) b1 on b1.receipt_id=b2.receipt_id
    where b2.tbl_id=table_id and b2.trang_thai=true;
end;
$$;

alter function tables_infor(varchar) owner to postgres;

