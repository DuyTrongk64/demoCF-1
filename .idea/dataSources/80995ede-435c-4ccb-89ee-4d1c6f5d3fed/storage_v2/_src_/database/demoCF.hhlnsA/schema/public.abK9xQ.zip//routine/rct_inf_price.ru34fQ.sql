create function rct_inf_price() returns trigger
    language plpgsql
as
$$
BEGIN
    update receipt_infor
    set
        pay = (select price*new.amount  from menu where new.ma_mon=menu.ma_mon)
    where  ma_mon=new.ma_mon ;
    RETURN NEW;
END;
$$;

alter function rct_inf_price() owner to postgres;

