create function find_by_tl(name character varying)
    returns TABLE(ma_mon character varying, ten_mon character varying, ma_loai character varying, price integer, dv character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        select m1.ma_mon,m1.ten_mon,m1.ma_loai,m1.price,m1.dv from menu m1,(select phanloai.ma_loai from phanloai where ten_loai = name) a1 where m1.ma_loai = a1.ma_loai;
end;
$$;

alter function find_by_tl(varchar) owner to postgres;

