create function tables_inf(table_id character varying)
    returns TABLE(ten_mon character varying, amount integer, price integer, pay integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        select b1.ten_mon, b1.amount, b1.price, b1.pay from (select a1.ten_mon,a1.price,a1.ma_mon,a2.amount,a2.pay,a2.receipt_id from menu  a1,
                                                                                                                                      (select receipt_id,receipt_infor.amount,receipt_infor.pay,receipt_infor.ma_mon from receipt_infor) a2
                                                             where a2.ma_mon=a1.ma_mon) b1,(select * from receipt) b2 where b2.tbl_id=table_id and b2.trang_thai=true and b2.receipt_id=b1.receipt_id;
end;
$$;

alter function tables_inf(varchar) owner to postgres;

