create function rct_update() returns trigger
    language plpgsql
as
$$
BEGIN
    update receipt
    set
        sum = (select sum(b1.pay) from (select * from receipt_infor where receipt.receipt_id=new.receipt_id) b1
        where b1.receipt_id= new.receipt_id)
    where receipt.receipt_id=new.receipt_id;
    RETURN NEW;
 END;
$$;

alter function rct_update() owner to postgres;

